import json
 
summary_headers = [
    "Introduction",
    "Key Functionalities/Capabilities",
    "Assumptions/Constraints/Recommendations"
]

requirement_headers = [
    "User/Usage Requirements", 
    "Interface Requirements",
    "Security Requirements",
    "Network Requirements",
    "Software Requirements",
    "Performance Requirements",
    "Supportability Requirements",
    "Storage Requirements",
    "Database Requirements",
    "Disaster Recovery Requirements",
    "Compliance Requirements",
    "Licensing Requirements"
]

solution_headers = [
    "Proposed New Architecture",
    "Pre-Production Architecture",
    "Production/DR Architecture"
]

ec2_table_headers = [
    "Environment",
    "Account Type",
    "Network Zone",
    "AWS Region",
    "AZ",
    "OS",
    "Instance Type CPU/RAM",
    "Count",
    "Storage Type",
    "Storage Volume Size",
    "Domain/DNS",
    "Data Residency Restrictions",
    "Data Classification",
    "Server Role",
    "On/Off Scheduling"
]

servers_table_headers = [
    "Environment/Location",
    "Server Type",
    "OS",
    "Network Zone",
    "CPU Cores",
    "RAM",
    "Non-OS SAN Storage",
    "Count",
    "Domain/DNS",
    "Data Residency Restrictions",
    "Data Classification",
    "Server Role"
]

deployment_details_headers = [
    "Hosted Location",
    "Countries/Regions Serviced",
    "Business Unit(s)"
]

def parse_arb(pdf_path='', pdf_file=None, local=False):
    import fitz  # lazy import so docx-only environments don't require pymupdf
    if local:
        arb = fitz.open(pdf_path)
    else:
        file_stream = pdf_file.read()
        arb = fitz.open(stream=file_stream, filetype='pdf')

    section_content = {}

    summary = extract_section(arb, "Summary", "Solution Requirements", summary_headers)
    section_content.update(summary)

    requirements = extract_section(arb, "Solution Requirements", "Affinity/Anti-Affinity Requirements", requirement_headers)
    section_content.update(requirements)

    proposed_solution = extract_section(arb, "Proposed Solution", "EC2 Sizing/Specifications (Guidance on OS Volumes & MS Office Support)", solution_headers)
    prune(proposed_solution)
    section_content["Proposed Solution"] = proposed_solution

    ec2s = extract_table(arb, "EC2 Sizing/Specifications", "On-Prem Servers Sizing/Specifications", ec2_table_headers)
    section_content["EC2 Sizing/Specifications"] = ec2s

    servers = extract_table(arb, "On-Prem Servers Sizing/Specifications", "Proposed Server Details", servers_table_headers)
    section_content["On-Prem Servers Sizing/Specification"] = servers

    deployment_details = extract_table(arb, "Hosted Location", "Miscellaneous Information", deployment_details_headers, False)
    section_content["Deployment Details"] = deployment_details

    output_path = "./file_processing/data/arb.json"

    with open(output_path, 'w') as jsonfile:
        json.dump(section_content, jsonfile, indent=4)

    arb.close()

    return section_content



def extract_section(doc, section_header, ending_header, subheaders):
    sections = {}
    at_section = False
    cur_subsection = ''
    header_count = 0

    for page_number in range(len(doc)):
        page = doc.load_page(page_number)
        page_text = page.get_text("text")

        for line in page_text.splitlines():
            line = line.strip()
            if line == section_header:
                header_count += 1

                if header_count == 2:
                    at_section = True
                    continue
            
            if at_section and line == ending_header:
                break

            if at_section:
                if line in subheaders:
                    cur_subsection = line
                    sections[cur_subsection] = ''
                else:
                    if cur_subsection != '':
                        sections[cur_subsection] = sections[cur_subsection] + line + " "
        else:
            continue
        break

    return sections


def extract_table(doc, table_header, ending_header, table_headers, section_header=True):
    desired_table = []
    at_table = False
    entries = []

    for page_number in range(len(doc)):
        page = doc.load_page(page_number)

        if not at_table:
            tabs = page.find_tables()
            for table in tabs.tables:
                cur_table = table.extract()

                if table_header in cur_table[0][0]:
                    for line in cur_table:
                        desired_table.append(line)

                    at_table = True
                else:
                    continue
        else:
            tabs = page.find_tables()
            for table in tabs.tables:
                cur_table = table.extract()

                if ending_header in cur_table[0][0]:
                    break

                for line in cur_table:
                    desired_table.append(line)
            else:
                continue
            break
    
    
    start_index = 2 if section_header else 1

    for row in desired_table[start_index:]:
        if row[0] == '':
            break
            
        entry = {}

        for index, item in enumerate(row):
            entry[table_headers[index]] = item.replace('\n', ' ')

        entries.append(entry)

    return entries


def prune(section):
    if not isinstance(section, dict):
        return

    empty = [key for key, value in section.items() if not value]
    for key in empty:
        del section[key]


def parse_arb_docx(docx_path='', docx_file=None, local=False):
    """Parse a Word (.docx) ASD into the same dict shape as parse_arb.

    Accepts either a path (``local=True``) or any file-like object (a
    ``werkzeug.FileStorage`` from Flask, a ``BytesIO``, etc.).
    """
    from docx import Document  # local import; only needed when called

    if local:
        doc = Document(docx_path)
    else:
        doc = Document(docx_file)

    blocks = list(_iter_blocks(doc))

    section_content = {}

    summary = _docx_extract_section(blocks, "Summary",
                                    "Solution Requirements",
                                    summary_headers)
    section_content.update(summary)

    requirements = _docx_extract_section(blocks, "Solution Requirements",
                                         "Affinity/Anti-Affinity Requirements",
                                         requirement_headers)
    section_content.update(requirements)

    proposed = _docx_extract_section(blocks, "Proposed Solution",
                                     "EC2 Sizing/Specifications (Guidance on OS Volumes & MS Office Support)",
                                     solution_headers)
    prune(proposed)
    section_content["Proposed Solution"] = proposed

    section_content["EC2 Sizing/Specifications"] = _docx_extract_table(
        blocks, "EC2 Sizing/Specifications", ec2_table_headers)
    section_content["On-Prem Servers Sizing/Specification"] = _docx_extract_table(
        blocks, "On-Prem Servers Sizing/Specifications", servers_table_headers)
    section_content["Deployment Details"] = _docx_extract_table(
        blocks, "Hosted Location", deployment_details_headers)

    return section_content


def _iter_blocks(document):
    """Yield (kind, payload) tuples in true document order.

    kind is "p" for paragraph text or "t" for a docx table object.
    """
    from docx.oxml.ns import qn

    body = document.element.body
    para_iter = iter(document.paragraphs)
    table_iter = iter(document.tables)
    para_map = {p._p: p for p in document.paragraphs}
    table_map = {t._tbl: t for t in document.tables}
    for child in body.iterchildren():
        if child.tag == qn('w:p'):
            p = para_map.get(child)
            if p is not None:
                yield ("p", (p.text or "").strip())
        elif child.tag == qn('w:tbl'):
            t = table_map.get(child)
            if t is not None:
                yield ("t", t)


def _docx_extract_section(blocks, section_header, ending_header, subheaders):
    sections = {}
    in_section = False
    cur_sub = ''
    for kind, payload in blocks:
        if kind != "p":
            continue
        line = payload
        if line == section_header and not in_section:
            in_section = True
            continue
        if in_section and line == ending_header:
            break
        if in_section:
            if line in subheaders:
                cur_sub = line
                sections[cur_sub] = ''
            else:
                if cur_sub and line:
                    sections[cur_sub] = sections[cur_sub] + line + ' '
    return sections


def _docx_extract_table(blocks, table_header, table_headers):
    """Find the first table that immediately follows a paragraph equal to
    ``table_header`` (or contains it) and return its data rows as dicts."""
    target_table = None
    saw_header = False
    for kind, payload in blocks:
        if kind == "p":
            text = payload
            if text == table_header or table_header in text:
                saw_header = True
                continue
            if saw_header and text:
                # If we encountered another heading without a table, abort.
                pass
        elif kind == "t" and saw_header:
            target_table = payload
            break
    if target_table is None:
        return []
    rows: list[dict] = []
    table_rows = list(target_table.rows)
    if len(table_rows) <= 1:
        return []
    for tr in table_rows[1:]:
        cells = [c.text.replace('\n', ' ').strip() for c in tr.cells]
        if not any(cells) or cells[0] == '':
            break
        entry = {}
        for i, val in enumerate(cells):
            if i >= len(table_headers):
                break
            entry[table_headers[i]] = val
        rows.append(entry)
    return rows


def extract_policies(pdf_path):
    import fitz  # lazy import
    pdf_document = fitz.open(pdf_path)

    sections = {}
    cur_line = ''
 
    for page_number in range(len(pdf_document)):
        page = pdf_document[page_number]
 
        page_text = page.get_text("text")

        for line in page_text.splitlines():
            if line.isupper() and 'INTERNAL' not in line and line.startswith(('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')):
                line = line.strip()
                cur_line = line
                sections[cur_line] = ''
            else:
                if cur_line != '':
                    sections[cur_line] = sections[cur_line] + line.strip()

    pdf_document.close()
 
    json_array = [{"header": key, "content": value} for key, value in sections.items()]

    return json_array
 

def extract_policies_docx(docx_path):
    """Extract policy sections from a Word document.

    Mirrors `extract_policies` (which targets PDF via PyMuPDF): a section
    header is any paragraph whose text is UPPERCASE, does not contain
    'INTERNAL', and starts with a digit (e.g. `1. IDENTITY AND ACCESS
    MANAGEMENT`). All non-header paragraphs accumulate into the most-recent
    section's content.
    """
    from docx import Document

    doc = Document(docx_path)

    sections = {}
    cur_line = ''

    for para in doc.paragraphs:
        line = (para.text or '').strip()
        if not line:
            continue
        if (line.isupper()
                and 'INTERNAL' not in line
                and line.startswith(('0', '1', '2', '3', '4', '5', '6', '7', '8', '9'))):
            cur_line = line
            sections[cur_line] = ''
        else:
            if cur_line:
                sections[cur_line] = sections[cur_line] + ' ' + line if sections[cur_line] else line

    return [{"header": k, "content": v} for k, v in sections.items()]
